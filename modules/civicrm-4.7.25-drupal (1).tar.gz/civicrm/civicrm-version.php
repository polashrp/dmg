<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.7.25',
                'cms'      => 'Drupal',
                'revision' => '' );
}

